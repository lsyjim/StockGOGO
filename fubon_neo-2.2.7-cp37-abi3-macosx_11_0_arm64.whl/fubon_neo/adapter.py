"""
Adapter layer for converting Mode enum to python-master HealthCheckConfig
This preserves backward compatibility while using the new parameterized SDK
"""

from enum import Enum
from typing import Dict
from fugle_marketdata import WebSocketClient, RestClient, HealthCheckConfig
from fubon_neo._fubon_neo import FugleRealtime


class Mode(Enum):
    """
    Mode enum for backward compatibility
    Maps to different WebSocket endpoint URLs
    """
    Speed = 'speed'
    Normal = 'normal'


class WebSocketStockClientWrapper:
    """
    Wrapper for WebSocketStockClient with Speed mode channel validation
    Preserves Fubon-specific channel restrictions for Speed mode
    """

    def __init__(self, stock_client, mode: Mode):
        self._client = stock_client
        self._mode = mode

    def subscribe(self, params):
        """
        Override subscribe to add Speed mode channel validation
        Speed mode doesn't support 'aggregates' and 'candles' channels
        """
        if self._mode == Mode.Speed:
            channel = params.get('channel')
            if channel in ('aggregates', 'candles'):
                raise Exception(f"Speed mode doesn't support {channel} channel")

        return self._client.subscribe(params)

    def __getattr__(self, name):
        """Delegate all other methods to the original client"""
        return getattr(self._client, name)


class WebSocketFutOptClientWrapper:
    """
    Wrapper for WebSocketFutOptClient with Speed mode channel validation
    Preserves Fubon-specific channel restrictions for Speed mode
    """

    def __init__(self, futopt_client, mode: Mode):
        self._client = futopt_client
        self._mode = mode

    def subscribe(self, params):
        """
        Override subscribe to add Speed mode channel validation
        Speed mode doesn't support 'aggregates' and 'candles' channels
        """
        if self._mode == Mode.Speed:
            channel = params.get('channel')
            if channel in ('aggregates', 'candles'):
                raise Exception(f"Speed mode doesn't support {channel} channel")

        return self._client.subscribe(params)

    def __getattr__(self, name):
        """Delegate all other methods to the original client"""
        return getattr(self._client, name)


def build_websocket_config(
    mode: Mode,
    sdk_token: str
) -> dict:
    """
    Build WebSocket configuration from Mode enum
    Converts legacy Mode-based API to new healthCheck config

    Args:
        mode: Speed or Normal mode
        sdk_token: SDK authentication token

    Returns:
        Configuration dictionary for WebSocket client
    """
    # Get the appropriate URL based on mode using static methods
    base_url = (
        FugleRealtime.realtime_ws_speed_url()
        if mode == Mode.Speed
        else FugleRealtime.realtime_ws_normal_url()
    )

    return {
        'base_url': f"{base_url}/v1.0",
        'sdk_token': sdk_token,
        'health_check': HealthCheckConfig(
            enabled=True,          # Always enable for Fubon customers
            ping_interval=30000,   # 30 seconds
            max_missed_pongs=2     # Disconnect after 2 missed pongs
        )
    }


class WebSocketClientWrapper:
    """
    Wrapper for WebSocketClient to intercept stock and futopt property access
    Cannot directly assign to stock/futopt properties (read-only), so we wrap the entire client
    """

    def __init__(self, client: WebSocketClient, mode: Mode):
        self._client = client
        self._mode = mode
        self._stock_wrapper = None
        self._futopt_wrapper = None

    def __getattr__(self, name):
        """Intercept attribute access to wrap stock and futopt clients"""
        if name == 'stock':
            # Lazy create and cache stock wrapper
            if self._stock_wrapper is None:
                self._stock_wrapper = WebSocketStockClientWrapper(self._client.stock, self._mode)
            return self._stock_wrapper
        elif name == 'futopt':
            # Lazy create and cache futopt wrapper
            if self._futopt_wrapper is None:
                self._futopt_wrapper = WebSocketFutOptClientWrapper(self._client.futopt, self._mode)
            return self._futopt_wrapper
        else:
            # Delegate all other attributes to the original client
            return getattr(self._client, name)


def build_websocket_client(mode: Mode, sdk_token: str) -> WebSocketClientWrapper:
    """
    Build WebSocket client with Mode-based configuration and channel validation

    Args:
        mode: Speed or Normal mode
        sdk_token: SDK authentication token

    Returns:
        WebSocketClientWrapper instance with wrapped stock and futopt clients for Speed mode validation
    """
    config = build_websocket_config(mode, sdk_token)
    client = WebSocketClient(**config)
    return WebSocketClientWrapper(client, mode)


def build_rest_config(sdk_token: str) -> dict:
    """
    Build REST client configuration

    Args:
        sdk_token: SDK authentication token

    Returns:
        Configuration dictionary for REST client
    """
    return {'sdk_token': sdk_token}


def build_rest_client(sdk_token: str) -> RestClient:
    """
    Build REST client with configuration

    Args:
        sdk_token: SDK authentication token

    Returns:
        RestClient instance
    """
    config = build_rest_config(sdk_token)
    return RestClient(**config)
